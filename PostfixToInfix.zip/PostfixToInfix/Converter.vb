﻿Imports System


Public Class Converter
    '  Check operator
    Public Function isOperator(ByVal text As Char) As Boolean
        If (text = "+"c OrElse
            text = "-"c OrElse
            text = "*"c OrElse
            text = "/"c OrElse
            text = "^"c OrElse
            text = "%"c) Then
            Return True
        End If
        Return False
    End Function
    '  Check operands
    Public Function isOperands(ByVal text As Char) As Boolean
        If ((text >= "0"c AndAlso text <= "9"c) OrElse
            (text >= "a"c AndAlso text <= "z"c) OrElse
        (text >= "A"c AndAlso text <= "Z"c)) Then
            Return True
        End If
        Return False
    End Function
    '  Converting the given postfix expression to 
    '  infix expression
    Public Function postfixToInfix(ByVal postfix As String)
        '  Get the size
        Dim size As Integer = postfix.Length
        '  Create stack object
        Dim s As MyStack = New MyStack()
        '  Some useful variables which is using 
        '  of to storing current result
        Dim auxiliary As String = ""
        Dim op1 As String = ""
        Dim op2 As String = ""
        Dim isValid As Boolean = True
        Dim i As Integer = 0
        While i < size AndAlso isValid
            '  Check whether given postfix location
            '  at [i] is an operator or not
            If (Me.isOperator(postfix(i))) Then
                '  When operator exist
                '  Check that two operands exist or not
                If (s.size() > 1) Then
                    op1 = s.pop()
                    op2 = s.pop()
                    auxiliary = "(" + op2 +
                      postfix(i).ToString() +
                    op1 + ")"
                    s.push(auxiliary)
                Else
                    isValid = False
                End If
            ElseIf (Me.isOperands(postfix(i))) Then
                '  When get valid operands
                auxiliary = postfix(i).ToString()
                s.push(auxiliary)
            Else
                '  Invalid operands or operator
                isValid = False
            End If
            i += 1
        End While
        If (isValid = False) Then
            '  When have something wrong
            MessageBox.Show("Invalid postfix ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBox1.Clear()
            TextBox2.Clear()
        Else

            TextBox2.Text = s.pop()
        End If



        Return s.pop()

    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox1.Text = Nothing Then


            MessageBox.Show("PLease Enter Postfix Expression ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
        Dim postfix As String = TextBox1.Text
        postfixToInfix(postfix)


    End Sub


    ' DESIGNS AND SIMPLE NAVIGATIONS 
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim result = MessageBox.Show(" Are you sure you want to Exit the App", "POSTFIX TO INFIX CONVERTER", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            Me.Close()
        End If

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Hide()
        GroupMembers.Show()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        GroupMembers.Show()
    End Sub
End Class



'  Stack Node
Public Class StackNode
    Public data As String
    Public [next] As StackNode
    Public Sub New(ByVal data As String,
                   ByVal top As StackNode)
        Me.data = data
        Me.next = top
    End Sub
End Class

Public Class MyStack
    Public top As StackNode
    Public count As Integer
    Public Sub New()
        Me.top = Nothing
        Me.count = 0
    End Sub
    '  Returns the number of element in stack
    Public Function size() As Integer
        Return Me.count
    End Function
    Public Function isEmpty() As Boolean
        If (Me.size() > 0) Then
            Return False
        Else
            Return True
        End If
    End Function
    '  Add a new element in stack
    Public Sub push(ByVal data As String)
        '  Make a new stack node
        '  And set as top
        Me.top = New StackNode(data, Me.top)
        '  Increase node value
        Me.count += 1
    End Sub
    '  Add a top element in stack
    Public Function pop() As String
        Dim temp As String = ""
        If (Me.isEmpty() = False) Then
            '  Get remove top value
            temp = Me.top.data
            Me.top = Me.top.[next]
            '  Reduce size
            Me.count -= 1
        End If
        Return temp
    End Function
    '  Used to get top element of stack
    Public Function peek() As String
        If (Not Me.isEmpty()) Then
            Return Me.top.data
        Else
            Return ""
        End If
    End Function
End Class
